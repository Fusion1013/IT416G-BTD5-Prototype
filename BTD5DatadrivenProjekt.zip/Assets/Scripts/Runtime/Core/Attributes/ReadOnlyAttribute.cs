using UnityEngine;

namespace Core.Attributes
{
    public class ReadOnlyAttribute : PropertyAttribute
    {
    }
}
